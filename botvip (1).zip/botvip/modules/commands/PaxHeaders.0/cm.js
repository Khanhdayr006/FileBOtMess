34 path=modules/commands/cấm.js
