const axios = require('axios');
const fs = require('fs');

module.exports.config = {
    name: "spt",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "HungCTer",
    description: "spotify",
    commandCategory: "Giải Trí",
    usages: "spt",
    cooldowns: 5
};

module.exports.handleReply = async function ({ api, event, handleReply }) {
    try {
        const index = parseInt(event.body);
        if (isNaN(index) || index < 1 || index > handleReply.results.length) {
            return api.sendMessage("Số thứ tự không hợp lệ.", event.threadID, event.messageID);
        }
        api.unsendMessage(handleReply.messageID);
        const selectedSong = handleReply.results[index - 1];
        const { title, duration, url } = selectedSong;

        const downloadUrlApi = `https://joshweb.click/api/spotify2?q=${encodeURIComponent(url)}`;
        let downloadUrl, artist;

        async function getDownloadUrl(apiUrl, retries = 3) {
            try {
                const downloadResponse = await axios.get(apiUrl);
                return downloadResponse.data.result;
            } catch (error) {
                if (error.code === 'ENOTFOUND' && retries > 0) {
                    await new Promise(resolve => setTimeout(resolve, 5000)); // Chờ 5 giây trước khi thử lại
                    return getDownloadUrl(apiUrl, retries - 1);
                }
                throw error;
            }
        }

        const result = await getDownloadUrl(downloadUrlApi);
        downloadUrl = result.download_url;
        artist = result.artist;

        if (!downloadUrl) {
            throw new Error("Không thể lấy được download_url.");
        }

        let path = __dirname + `/cache/${title}.mp3`;

        const dl = (await axios.get(downloadUrl, { responseType: "arraybuffer" })).data;
        fs.writeFileSync(path, Buffer.from(dl, "utf-8"));
        const durationMinutes = Math.floor(duration / 60000);
        const durationSeconds = ((duration % 60000) / 1000).toFixed(0);

        return api.sendMessage(
            {
                body: `[ SPOTIFY - DOWNLOAD ]\n—————————————————\n📝 Tiêu Đề: ${title}\n⏳ Thời Lượng: ${durationMinutes}:${durationSeconds < 10 ? '0' : ''}${durationSeconds}\n👤 Tác Giả: ${artist}\n—————————————————\n`,
                attachment: fs.createReadStream(path)
            },
            event.threadID,
            () => fs.unlinkSync(path)
        );
    } catch (error) {
        return api.sendMessage(`Đã xảy ra lỗi: ${error.message}`, event.threadID, event.messageID);
    }
};

module.exports.run = async function ({ api, event, args }) {
    try {
        let q = args.join(" ");
        if (!q) return api.sendMessage("⚠️ Vui lòng nhập từ khóa tìm kiếm", event.threadID, event.messageID);

        const searchResult = await axios.get(`https://joshweb.click/search/spotify?q=${encodeURIComponent(q)}`);
        const { status, result } = searchResult.data;

        if (!status || result.length === 0) return api.sendMessage("❗Không tìm thấy kết quả phù hợp.", event.threadID, event.messageID);

        const maxResults = 6;
        let message = "·• [ Kết quả tìm kiếm Spotify ]•·\n\n";
        for (let i = 0; i < Math.min(result.length, maxResults); i++) {
            const { title, artist, duration } = result[i];
            const durationMinutes = Math.floor(duration / 60000);
            const durationSeconds = ((duration % 60000) / 1000).toFixed(0);
            message += `${i + 1}. 🎵 Tiêu đề: ${title}\n⏳ Thời lượng: ${durationMinutes}:${durationSeconds < 10 ? '0' : ''}${durationSeconds}\n👤 Tác giả: ${artist}\n\n`;
        }
        message += "⩺ Reply số thứ tự để tải nhạc";

        api.sendMessage(message, event.threadID, (error, info) => {
            global.client.handleReply.push({
                type: "chooseSong",
                name: this.config.name,
                messageID: info.messageID,
                author: event.senderID,
                results: result.slice(0, maxResults)
            });
        });
    } catch (error) {
        return api.sendMessage(`Đã xảy ra lỗi: ${error.message}`, event.threadID, event.messageID);
    }
};
